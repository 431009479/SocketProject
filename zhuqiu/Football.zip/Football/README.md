## 足球游戏

#### 知识准备

* `C/S`

* `UDP`
* `ncurses`

##### 1. 球场大小

![image.png](http://ww1.sinaimg.cn/large/006Uqzbtly1gfaqj21hc6j30f508idg9.jpg)

![image.png](http://ww1.sinaimg.cn/large/006Uqzbtly1gfarx2a4loj30wb0kkag2.jpg)

![image.png](http://ww1.sinaimg.cn/large/006Uqzbtly1gfjpgdcgcfj30cq0ik0z5.jpg)

reactor dispatch反应堆调度
Acceptor受体
worker threads工作线程
Thread Pool线程池
Main Accpet thread主攻螺纹
sub-reactor thread子反应器线程

`3 epoll`

`2 arr team`

`2 thread-poll`

`work: echo string`

![image.png](http://ww1.sinaimg.cn/large/006Uqzbtly1gfrsokheapj30v609rq5k.jpg)

![image.png](http://ww1.sinaimg.cn/large/006Uqzbtly1gfrsozvj90j30ze0lctko.jpg)

![image.png](http://ww1.sinaimg.cn/large/006Uqzbtly1gfrz990xo2j30z90q54f3.jpg)

