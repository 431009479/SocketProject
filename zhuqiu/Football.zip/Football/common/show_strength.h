/*************************************************************************
	> File Name: show_strength.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年07月01日 星期三 00时28分39秒
 ************************************************************************/

#ifndef _SHOW_STRENGTH_H
#define _SHOW_STRENGTH_H
void show_strength();
#endif
