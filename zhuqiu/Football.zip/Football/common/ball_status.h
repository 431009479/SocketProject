/*************************************************************************
	> File Name: ball_status.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年07月02日 星期四 22时01分01秒
 ************************************************************************/

#ifndef _BALL_STATUS_H
#define _BALL_STATUS_H
int can_kick(struct Point *loc, int strength);
int ball_stop(struct Point *loc);
int ball_carry(struct Point *loc);
#endif
