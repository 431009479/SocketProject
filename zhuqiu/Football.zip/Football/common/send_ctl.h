/*************************************************************************
	> File Name: send_ctl.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年06月14日 星期日 20时07分53秒
 ************************************************************************/

#ifndef _SEND_CTL_H
#define _SEND_CTL_H
void send_ctl();
#endif
