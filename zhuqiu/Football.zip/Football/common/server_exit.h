/*************************************************************************
	> File Name: server.exit.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年06月13日 星期六 14时44分27秒
 ************************************************************************/

#ifndef _SERVER_EXIT_H
#define _SERVER_EXIT_H
void server_exit(int signum);
#endif
