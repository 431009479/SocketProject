/*************************************************************************
	> File Name: heart_beat.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年06月09日 星期二 20时27分45秒
 ************************************************************************/

#ifndef _HEART_BEAT_H
#define _HEART_BEAT_H
void heart_beat_team(struct User *team);
void *heart_beat(void *arg);
#endif
