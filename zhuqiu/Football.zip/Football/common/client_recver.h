/*************************************************************************
	> File Name: client_recver.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年06月13日 星期六 14时14分08秒
 ************************************************************************/

#ifndef _CLIENT_RECVER_H
#define _CLIENT_RECVER_H
void *client_recv(void *arg);
#endif
