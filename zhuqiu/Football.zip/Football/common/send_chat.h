/*************************************************************************
	> File Name: send_chat.h
	> Author:fangsong
	> Mail: 
	> Created Time: 2020年06月14日 星期日 16时51分28秒
 ************************************************************************/

#ifndef _SEND_CHAT_H
#define _SEND_CHAT_H
void send_chat();
#endif
